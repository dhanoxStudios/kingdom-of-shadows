Kingdom of Shadows - web build (single-file, offline)

Upload: unzip and upload the contents to the root of your website
(index.html is the game). For Netlify, drop the folder or connect the
GitHub repo; netlify.toml is included. No secrets or .env files inside.
